I'll update this later

## Getting Started

```bash
cp .env.sample env
docker compose up
npm i
npm run db:push
npm run dev
open http://localhost:3000
```

